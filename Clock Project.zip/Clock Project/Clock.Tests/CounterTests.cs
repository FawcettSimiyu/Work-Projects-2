﻿using NUnit.Framework;

namespace ClockProject.Tests
{
    [TestFixture]
    public class CounterTests
    {
        [Test]
        public void Counter_InitializesAtZero()
        {
            var counter = new Counter("test");
            Assert.That(counter.Ticks, Is.EqualTo(0));
        }

        [Test]
        public void Counter_IncrementAddsOne()
        {
            var counter = new Counter("test");
            counter.Increment();
            Assert.That(counter.Ticks, Is.EqualTo(1));
        }

        [Test]
        public void Counter_MultipleIncrements()
        {
            var counter = new Counter("test");
            counter.Increment();
            counter.Increment();
            counter.Increment();
            Assert.That(counter.Ticks, Is.EqualTo(3));
        }

        [Test]
        public void Counter_ResetSetsToZero()
        {
            var counter = new Counter("test");
            counter.Increment();
            counter.Increment();
            counter.Reset();
            Assert.That(counter.Ticks, Is.EqualTo(0));
        }
    }
}