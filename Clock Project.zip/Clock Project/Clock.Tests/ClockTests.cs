﻿using NUnit.Framework;

namespace ClockProject.Tests
{
    [TestFixture]
    public class ClockTests
    {
        [Test]
        public void Clock_InitializesToZero()
        {
            var clock = new Clock(true);
            Assert.That(clock.CurrentTime(), Is.EqualTo("00:00:00"));
        }

        [Test]
        public void Clock_TickIncrementsSeconds()
        {
            var clock = new Clock(true);
            clock.Tick();
            Assert.That(clock.CurrentTime(), Is.EqualTo("00:00:01"));
        }

        [Test]
        public void Clock_60TicksIncrementsMinute()
        {
            var clock = new Clock(true);
            for (int i = 0; i < 60; i++) clock.Tick();
            Assert.That(clock.CurrentTime(), Is.EqualTo("00:01:00"));
        }

        [Test]
        public void Clock_3600TicksIncrementsHour()
        {
            var clock = new Clock(true);
            for (int i = 0; i < 3600; i++) clock.Tick();
            Assert.That(clock.CurrentTime(), Is.EqualTo("01:00:00"));
        }

        [Test]
        public void Clock_24HourFormatResetsAt24()
        {
            var clock = new Clock(true);
            for (int i = 0; i < 86400; i++) clock.Tick();
            Assert.That(clock.CurrentTime(), Is.EqualTo("00:00:00"));
        }

        [Test]
        public void Clock_12HourFormatShowsPeriod()
        {
            var clock = new Clock(false);
            for (int i = 0; i < 43200; i++) clock.Tick();
            Assert.That(clock.CurrentTime(), Is.EqualTo("12:00:00 PM"));
        }

        [Test]
        public void Clock_ResetWorks()
        {
            var clock = new Clock(true);
            for (int i = 0; i < 3661; i++) clock.Tick();
            clock.Reset();
            Assert.That(clock.CurrentTime(), Is.EqualTo("00:00:00"));
        }
    }
}