using System;
using System.Threading;

namespace ClockProject
{
    public class Program
    {
        // Ensure only one Main method exists in the project
        static void Main(string[] args)
        {
            // Determine format based on last student ID digit
            bool is24HourFormat = true; // Change based on actual student ID

            var clock = new Clock(is24HourFormat);

            Console.WriteLine("Clock Test - Press ENTER to stop...");
            Console.WriteLine("Initial time: " + clock.CurrentTime());

            while (!Console.KeyAvailable)
            {
                clock.Tick();
                Console.WriteLine("Current time: " + clock.CurrentTime());
                Thread.Sleep(1000); // Wait 1 second between ticks
            }

            Console.ReadLine(); // This keeps the window open
        }
    }
}
