﻿namespace ClockProject
{
    public class Counter
    {
        private int _count;
        private readonly string _name;

        public Counter(string name)
        {
            _name = name;
            _count = 0;
        }

        public void Increment()
        {
            _count++;
        }

        public void Reset()
        {
            _count = 0;
        }

        public string Name => _name;
        public int Ticks => _count;
    }
}