﻿namespace ClockProject
{
    public class Clock
    {
        private readonly Counter _hours;
        private readonly Counter _minutes;
        private readonly Counter _seconds;
        private readonly bool _is24HourFormat;

        public Clock(bool is24HourFormat)
        {
            _hours = new Counter("hours");
            _minutes = new Counter("minutes");
            _seconds = new Counter("seconds");
            _is24HourFormat = is24HourFormat;
        }

        public void Tick()
        {
            _seconds.Increment();
            if (_seconds.Ticks >= 60)
            {
                _seconds.Reset();
                _minutes.Increment();

                if (_minutes.Ticks >= 60)
                {
                    _minutes.Reset();
                    _hours.Increment();

                    if (_is24HourFormat)
                    {
                        if (_hours.Ticks >= 24)
                        {
                            _hours.Reset();
                        }
                    }
                    else
                    {
                        if (_hours.Ticks >= 12)
                        {
                            _hours.Reset();
                        }
                    }
                }
            }
        }

        public void Reset()
        {
            _hours.Reset();
            _minutes.Reset();
            _seconds.Reset();
        }

        public string CurrentTime()
        {
            int hours = _hours.Ticks;
            string period = "";

            if (!_is24HourFormat)
            {
                period = hours < 12 ? " AM" : " PM";
                hours = hours % 12;
                if (hours == 0) hours = 12;
            }

            return $"{hours:D2}:{_minutes.Ticks:D2}:{_seconds.Ticks:D2}{period}";
        }
    }
}